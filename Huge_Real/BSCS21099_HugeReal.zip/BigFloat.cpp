#include "BigFloat.h"

#define BASE 10
int get_ith_last(const std::vector<int>& v, int i);

void BigFloat::normalize()
{
	int iExp = 0;
	int iMant = this->mant.size() - 1;

	while (iExp < this->exp.size() - 1 && this->exp[iExp] <= 0)
		iExp++;
	while (iMant > 0 && this->mant[iMant] <= 0)
		iMant--;
	for (int i = 0; i < iExp; i++)
	{
		this->exp.erase(exp.begin() + i);
	}
	this->mant.resize(iMant + 1);
}

BigFloat BigFloat::absSum(const BigFloat& f2) const
{
	BigFloat SUM(*this);
	const int maxExpSize = std::max(this->exp.size(), f2.exp.size()) + 1;
	SUM.exp.resize(maxExpSize);

	int carry = 0;
	for (int i = 0; i < maxExpSize; i++)
	{
		int currSum = get_ith_last(this->exp, i) + get_ith_last(f2.exp, i);
		SUM.exp[maxExpSize - 1 - i] = (carry + (currSum % BASE));
		carry = currSum / BASE;
	}
	//Sum the mantissa part just like I summed the exponent part
	int maxMantSize = std::max(this->mant.size(), f2.mant.size());
	SUM.mant.resize(maxMantSize);
	carry = 0;
	for (int i = 0; i < maxMantSize; i++)
	{
		int currSum = get_ith_last(this->mant, i) + get_ith_last(f2.mant, i);
		SUM.mant[maxMantSize - 1 - i] = (carry + (currSum % BASE));
		carry = currSum / BASE;
	}
	BigFloat carryBigFloat(std::to_string(carry));
	if (carry > 0)
	{
		SUM.normalize();
		SUM = SUM.absSum(carryBigFloat);
	}

	SUM.normalize();
	return SUM;
}

BigFloat::BigFloat()
	:sign(0), exp(0), mant(0)
{
}
BigFloat::BigFloat(const std::string& str)
	:BigFloat()
{
	int i = 0;
	if (str[0] == '-')
	{
		this->sign = 1; i++;
	}
	const int strSize = str.size();
	while (str[i] != '.' && i < strSize)
	{
		exp.push_back(str[i] - '0');
		i++;
	}
	i++;
	while (i < strSize)
	{
		mant.push_back(str[i] - '0');
		i++;
	}
}

BigFloat::BigFloat(const BigFloat& src)
	:sign(src.sign), exp(src.exp), mant(src.mant)
{
}

BigFloat::BigFloat(BigFloat&& src) noexcept
	:sign(src.sign), exp(std::move(src.exp)), mant(std::move(src.mant))
{
}

BigFloat::BigFloat(const int src)
{
}

BigFloat::BigFloat(const double src)
{
}

BigFloat::~BigFloat()
{
}

BigFloat BigFloat::operator+(const BigFloat& f2) const
{
	BigFloat SUM;
	if (this->sign == f2.sign)
	{
		SUM.sign = this->sign;
		SUM.exp = this->exp;
		SUM.mant = this->mant;
		//SUM.mant.insert(SUM.mant.end(), f2.mant.begin(), f2.mant.end());
		return this->absSum(f2);
		//
		//SUM.normalize();
	}
	else
	{
		if (*this > f2)
		{
			SUM.sign = this->sign;
			SUM.exp = this->exp;
			SUM.mant = this->mant;
			SUM.mant.insert(SUM.mant.end(), f2.mant.begin(), f2.mant.end());
			return this->absSum(f2);
			//SUM.normalize();
		}
		else
		{
			SUM.sign = f2.sign;
			SUM.exp = f2.exp;
			SUM.mant = f2.mant;
			SUM.mant.insert(SUM.mant.end(), this->mant.begin(), this->mant.end());
			//SUM.exp += this->exp;
			SUM.normalize();
		}
	}
}

void BigFloat::operator = (const BigFloat& f2)
{
	this->sign = f2.sign;
	this->exp = std::move(f2.exp);
	this->mant = std::move(f2.mant);
}


BigFloat BigFloat::operator-(const BigFloat& f2) const
{
	return BigFloat();
}

BigFloat BigFloat::operator*(const BigFloat& f2) const
{
	return BigFloat();
}

BigFloat BigFloat::operator/(const BigFloat& f2) const
{
	return BigFloat();
}

std::ostream& operator<<(std::ostream& os, const BigFloat& f)
{
	os << (f.sign == 1 ? '-' : char(0));
	for (int i : f.exp)
		os << i;
	os << '.';
	for (int i : f.mant)
		os << i;
	return os;
}
bool BigFloat::operator > (const BigFloat& f2) const
{
	if (this->sign != f2.sign)
		return this->sign < f2.sign;
	for (int i = 0; i < this->exp.size(); i++)
	{
		if (this->exp[i] > f2.exp[i])
			return true;
	}
	for (int i = 0; i < this->mant.size(); i++)
	{
		if (this->mant[i] > f2.mant[i])
			return true;
	}
	return false;
}
bool BigFloat::operator < (const BigFloat& f2) const
{
	return !(*this > f2) && (*this != f2);
}
bool BigFloat::operator != (const BigFloat& f2) const
{
	return !(*this == f2);
}
bool BigFloat::operator == (const BigFloat& f2) const
{
	return this->sign == f2.sign && this->exp == f2.exp && this->mant == f2.mant;
}

int get_ith_last(const std::vector<int>& v, int i)
{
	if (i >= 0 && i < v.size())
		return v.at(v.size() - 1 - i);
	else
		return 0;
}

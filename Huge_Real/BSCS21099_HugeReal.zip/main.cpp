#include <iostream>
#include "BigFloat.h"
using namespace std;

int main() {
	BigFloat f1("990.83");
	BigFloat f2("5.30");
	cout << "AAA\n";
	cout << f1.absSum(f2);
	return 0;
}